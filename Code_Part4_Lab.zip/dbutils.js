var mongostr = {                 // local machine
		"hostname":"localhost", 
		"port":27017, 
		"username":"test", 
		"password":"1234",  
		"name":"", 
		"db":"course" 
}
if(process.env.OPENSHIFT_NODEJS_PORT){   // OpenShift
	mongostr = { 
		"hostname":process.env.OPENSHIFT_MONGODB_DB_HOST, 
		"port":process.env.OPENSHIFT_MONGODB_DB_PORT, 
		"username":process.env.OPENSHIFT_MONGODB_DB_USERNAME, 
		"password": process.env.OPENSHIFT_MONGODB_DB_PASSWORD,  
		"name":"", 
		"db":"mycourse" 
	}
}
exports.getMongoUrl = function() {
     return "mongodb://" + mongostr.username + ":" + 
			mongostr.password + "@" + mongostr.hostname + ":" 
			+ mongostr.port + "/" + mongostr.db; 
} 


