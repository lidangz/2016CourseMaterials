var express = require('express');
var handlers = require('./handlers');

var ip_address = process.env.OPENSHIFT_NODEJS_IP || '127.0.0.1';     
var port      = process.env.OPENSHIFT_NODEJS_PORT || 8080;  

var app = express();
app.configure(function () {
    app.use(express.logger('dev'));  
    app.use(express.bodyParser());
});
 
console.log ('registering event routes with express');

app.get('/', handlers.start);
app.get('/materials', handlers.listAll);
app.get('/materials/:cat', handlers.listByCat);
app.post('/materials', handlers.upload);
app.get('/files/:fileId/:fileName', handlers.download);
app.delete('/materials/:id', handlers.delete);

console.log ('About to start listening');
app.listen(port,ip_address);
console.log('Listening on port: ', port, ' of ', ip_address);



